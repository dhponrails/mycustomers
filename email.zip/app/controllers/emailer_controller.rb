class EmailerController < ApplicationController




end
