class Campaign < ActiveRecord::Base
belongs_to :user

end
