class Design < ActiveRecord::Base
end
