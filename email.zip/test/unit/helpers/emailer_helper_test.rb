require 'test_helper'

class EmailerHelperTest < ActionView::TestCase
end
